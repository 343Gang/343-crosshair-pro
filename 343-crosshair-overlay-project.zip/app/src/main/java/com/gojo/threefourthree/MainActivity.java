package com.gojo.threefourthree;
import android.app.*;import android.content.*;import android.graphics.Color;import android.net.Uri;import android.os.*;import android.provider.Settings;import android.view.*;import android.widget.*;
public class MainActivity extends Activity{
 LinearLayout box; int red=Color.rgb(255,32,40);
 public void onCreate(Bundle b){super.onCreate(b);box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(35,60,35,30);box.setBackgroundColor(Color.rgb(5,5,5));
 TextView t=new TextView(this);t.setText("343 CROSSHAIR PRO");t.setTextColor(red);t.setTextSize(28);t.setGravity(17);box.addView(t,new LinearLayout.LayoutParams(-1,120));
 TextView i=new TextView(this);i.setText("\nAllow overlay permission, then tap START.\nYou can drag the crosshair on screen.");i.setTextColor(Color.LTGRAY);i.setTextSize(17);box.addView(i,new LinearLayout.LayoutParams(-1,0,1));
 Button p=btn("ALLOW DISPLAY OVER OTHER APPS"),s=btn("START CROSSHAIR"),x=btn("STOP CROSSHAIR");box.addView(p);box.addView(s);box.addView(x);setContentView(box);
 p.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))));
 s.setOnClickListener(v->{if(!Settings.canDrawOverlays(this)){Toast.makeText(this,"Allow overlay permission first",Toast.LENGTH_LONG).show();return;}Intent z=new Intent(this,OverlayService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(z);else startService(z);});
 x.setOnClickListener(v->stopService(new Intent(this,OverlayService.class))); }
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setBackgroundColor(red);b.setLayoutParams(new LinearLayout.LayoutParams(-1,70));return b;}
}