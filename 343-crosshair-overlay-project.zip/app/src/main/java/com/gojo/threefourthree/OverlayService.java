package com.gojo.threefourthree;
import android.app.*;import android.content.*;import android.graphics.*;import android.os.*;import android.view.*;
public class OverlayService extends Service{
 WindowManager wm; CrossView v; WindowManager.LayoutParams p;
 public void onCreate(){super.onCreate();if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("cross","343 Crosshair",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager.class).createNotificationChannel(c);startForeground(7,new Notification.Builder(this,"cross").setContentTitle("343 Crosshair Pro").setContentText("Crosshair is running").setSmallIcon(com.gojo.threefourthree.R.drawable.crosshair_icon).build());}
 wm=(WindowManager)getSystemService(WINDOW_SERVICE);v=new CrossView(this);int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;p=new WindowManager.LayoutParams(120,120,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT);p.gravity=Gravity.CENTER;wm.addView(v,p);
 v.setOnTouchListener((q,e)->{if(e.getAction()==MotionEvent.ACTION_DOWN){v.dx=e.getRawX()-p.x;v.dy=e.getRawY()-p.y;return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){p.x=(int)(e.getRawX()-v.dx);p.y=(int)(e.getRawY()-v.dy);wm.updateViewLayout(v,p);return true;}return true;});}
 public void onDestroy(){if(v!=null)wm.removeView(v);super.onDestroy();}public android.os.IBinder onBind(Intent i){return null;}
 static class CrossView extends View{Paint a=new Paint(3);float dx,dy;CrossView(Context c){super(c);a.setColor(Color.RED);a.setStrokeWidth(5);}
 protected void onDraw(Canvas c){float x=getWidth()/2f,y=getHeight()/2f;c.drawLine(x,8,x,46,a);c.drawLine(x,74,x,112,a);c.drawLine(8,y,46,y,a);c.drawLine(74,y,112,y,a);c.drawCircle(x,y,5,a);}}
}